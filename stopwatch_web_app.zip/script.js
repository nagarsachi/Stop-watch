let [hours, minutes, seconds] = [0, 0, 0];
let timer = null;
const display = document.getElementById("display");
const laps = document.getElementById("laps");
document.getElementById("start").addEventListener("click", () => {
  if (timer !== null) return;
  timer = setInterval(runStopwatch, 1000);
});
document.getElementById("pause").addEventListener("click", () => {
  clearInterval(timer);
  timer = null;
});
document.getElementById("reset").addEventListener("click", () => {
  clearInterval(timer);
  timer = null;
  [hours, minutes, seconds] = [0, 0, 0];
  displayTime();
  laps.innerHTML = "";
});
document.getElementById("lap").addEventListener("click", () => {
  const li = document.createElement("li");
  li.innerText = display.innerText;
  laps.appendChild(li);
});
function runStopwatch() {
  seconds++;
  if (seconds === 60) {
    seconds = 0;
    minutes++;
  }
  if (minutes === 60) {
    minutes = 0;
    hours++;
  }
  displayTime();
}
function displayTime() {
  const h = String(hours).padStart(2, '0');
  const m = String(minutes).padStart(2, '0');
  const s = String(seconds).padStart(2, '0');
  display.innerText = `${h}:${m}:${s}`;
}